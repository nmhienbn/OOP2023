

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

public class Layer {
    private ArrayList<Shape> shapes;

    /** Hien. */
    public void addShape(Shape shape) {
        shapes.add(shape);
    }

    /** Hien. */
    public void removeCircles() {
        for (int i = 0; i < shapes.size(); ++i) {
            if (shapes.get(i) instanceof Circle) {
                shapes.remove(i);
            }
        }
    }

    /** Hien. */
    public String getInfo() {
        StringBuilder res = new StringBuilder();
        res.append("Layer of crazy shapes: \n");
        for (Shape shape : shapes) {
            res.append(shape);
            res.append('\n');
        }
        return res.toString();
    }

    /** Hien. */
    public void removeDuplicates() {
        Set<Shape> shapeSet = new HashSet<>(shapes);
        shapes.clear();
        shapes.addAll(shapeSet);
    }
}
