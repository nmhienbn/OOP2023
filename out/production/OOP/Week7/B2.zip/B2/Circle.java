

import java.util.Objects;

public class Circle extends Shape {
    protected Point center;
    protected double radius;

    /** Hien. */
    public Circle() {
    }

    /** Hien. */
    public Circle(double radius) {
        this.radius = radius;
    }

    /** Hien. */
    public Circle(double radius, String color, boolean filled) {
        super(color, filled);
        this.radius = radius;
    }

    /**
     * Hien.
     */
    public Circle(Point center, double radius, String color, boolean filled) {
        super(color, filled);
        this.center = center;
        this.radius = radius;
    }

    /** Hien. */
    public Point getCenter() {
        return center;
    }

    /** Hien. */
    public void setCenter(Point center) {
        this.center = center;
    }

    /** Hien. */
    public double getRadius() {
        return radius;
    }

    /** Hien. */
    public void setRadius(double radius) {
        this.radius = radius;
    }

    @Override
    public double getArea() {
        return Math.PI * radius * radius;
    }

    @Override
    public double getPerimeter() {
        return 2 * Math.PI * radius;
    }

    @Override
    public String toString() {
        return "Circle[circle=" + center + ",radius=" + radius + ",color=" + color + ",filled=" + filled + "]";
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Circle circle)) return false;
        return Double.compare(getRadius(), circle.getRadius()) == 0 && Objects.equals(getCenter(), circle.getCenter());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getCenter(), getRadius());
    }
}
